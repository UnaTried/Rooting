<div align="center" style="margin: 8px;">

# iUnlocker GLTool 

![Latest Version](https://img.shields.io/github/v/release/i-Taylo/iUnlockerGL?color=blue&label=Latest%20Version)
[![Downloads](https://img.shields.io/github/downloads/i-Taylo/iUnlockerGL/total?color=green&label=Downloads)](https://github.com/i-Taylo/iUnlockerGL/releases/latest)



iUnlocker GLTool is a Magisk module designed to spoof GPU information, allowing users to modify GPU information for unlocking graphics in games and testing.

---
</div>

## Features

**What iUnlockerGL can spoof:**
- OpenGL info (Vendor, Model, Version, Extensions)
- Vulkan specifications (Model, Driver version, Memory, Limits)
- Display properties (Refresh rate, HDR Support, Wide color gamut)
- Device model/brand/build props
- CPU details & architecture (CPU id, Capabilities)
- RAM size & Frequency

---

<div align="center" style="margin: 8px;">
| API           | Status |
|----------------|--------|
| OpenGL ES      | ![Supported](https://img.shields.io/badge/-Supported-brightgreen) |
| Vulkan         | ![Supported](https://img.shields.io/badge/-Supported-brightgreen) |

<br>

| Chipset        | Status |
|----------------|--------|
| Snapdragon     | ![Working](https://img.shields.io/badge/-Working-success) |
| MediaTek       | ![Working](https://img.shields.io/badge/-Working-success) |
| Exynos         | ![Working](https://img.shields.io/badge/-Working-success) |
| Others         | ![Working](https://img.shields.io/badge/-Working-success) |

| Architecture   | Status |
|----------------|--------|
| arm64-v8a      | ![Tested](https://img.shields.io/badge/-Tested-blue) |
| armeabi-v7a    | ![Untested](https://img.shields.io/badge/-Untested-lightgrey) |
| x86            | ![Untested](https://img.shields.io/badge/-Untested-lightgrey) |
| x86_64         | ![Untested](https://img.shields.io/badge/-Untested-lightgrey) |

---

### Requirements
|   |   |
------|-----------|
| Android | Android API 27 and higher |
| Root | Magisk v26.4+ |
|  | **OR** |
| Root | KernelSU (latest) |

---
</div>

<div align="center" style="margin: 8px;">

### How to Install
<div align="left" style="margin: 8px;">

1. Download module ZIP file from [releases](https://github.com/i-Taylo/iUnlockerGL/releases) page
    * The ZIP file contains the app, so there's no need to download it separately
2. 
    * [Magisk] Open Magisk -> navigate to **Settings** -> enable **Zygisk**
    * [KernelSU] Download [ZygiskNext](https://github.com/Dr-TSNG/ZygiskNext/releases/tag/v1.2.5) -> flash it in KSU then reboot your phone
3. Flash the iUnlocker-GlTool-for-android-\<latest-version>.zip (Make sure to report any errors), then reboot
---
<div>


</div> 
<!-- ENDOF HOW TO INSTALL -->
<div align="center" style="margin: 8px;">

### Copyright Notice
Copyright © 2020 iUnlocker</br> All rights reserved.

# iUnlockerGL ![iUnlocker GLTool](https://img.shields.io/github/v/tag/i-Taylo/iUnlockerGL?color=white&label=)
License Agreement

<div align="left" style="margin: 8px;">

This is a legal agreement between you and Taylo for using iUnlockerGL software. By using the software, you accept these terms.

## Key Terms

1. **Usage Rights**
   - You may use the software for personal, educational, or demonstrational purposes
   - You may share the original, unmodified software (including on platforms like YouTube)
   - Commercial use of the software itself is prohibited (see restrictions below)

2. **Restrictions**
You MAY NOT:
- Reverse engineer, decompile, or modify the software
- Remove, alter, or obscure copyright notices
- Extract/reuse code in other projects
- Use the software for commercial purposes*, including:
  - Selling the software or derivative works
  - Integrating it into paid services/products
  - Business operations that rely on this software

*Exception: Monetized videos/tutorials about the software are allowed.

3. **Ownership and Liability**
   - Taylo retains all intellectual property rights
   - Software is provided "as is" without warranties
   - Taylo is not liable for any damages from software use

By using iUnlockerGL, you confirm that you understand and agree to these terms.

- > [LICENSE](https://github.com/i-Taylo/iUnlockerGL/blob/main/LICENSE)
</div>

---

</div>

<div align="center" style="margin: 28px;">

###  LINKS

<a href="https://t.me/v9y_7v3">
    <img src="https://img.shields.io/badge/Telegram-blue?logo=telegram" 
         alt="Telegram Badge" 
         style="width: 110px; border-radius: 10px;">
</a>
</br>


</div>