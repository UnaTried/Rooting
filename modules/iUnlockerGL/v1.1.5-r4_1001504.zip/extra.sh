#!/data/adb/iunlocker/bin/bash

##############################################
#   extra.sh script by Taylo @ github.com/i-taylo
#   used for executing extra operations before main updater
##############################################
SDK_ROOTDIR="/data/adb/iunlocker"
